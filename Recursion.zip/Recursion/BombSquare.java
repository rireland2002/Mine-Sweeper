import java.util.*;

public class BombSquare extends GameSquare
{
	private boolean thisSquareHasBomb = false;//The boolean for whether a square has a bomb or not
	private boolean clicked;//The boolean for whether a square has been clicked or not
	
	public static final int MINE_PROBABILITY = 10;//The probability of a square having a bomb

	public BombSquare(int x, int y, GameBoard board)//Constructor for a bomb square, takes the x and y position and the board the squares will be on
	{
		super(x, y, "images/blank.png", board);//The super constructor for GameSquare, also sets all tiles to blank

		Random r = new Random();
		thisSquareHasBomb = (r.nextInt(MINE_PROBABILITY) == 0);//Determines whether the square will have a bomb or not
	}


	public int bombchecker()//Method for checking the amount of bombs in the tiles around the current square
	{
		int bombcount = 0;//Sets the bomb count to 0
		for(int x = -1; x<=1;x++)//Creates an integer x that mimics the x co-ordinate of the bombsquare, goes through all the x positions around the current square
			{
				for(int y = -1; y<=1;y++)//Creates an integer y that mimics the x co-ordinate of the bombsquare, goes through all the y positions around the current square
				{
					GameSquare gs = board.getSquareAt(this.xLocation + x, this.yLocation + y);//Sets the gamesquare gs to the current square based on the x and y variables
					BombSquare xs = (BombSquare)gs;//Casts the GameSquare gs to type BombSquare and stores in xs
					if(xs != null)//Makes sure that xs is not out of bounds
					{
						if(xs.thisSquareHasBomb == true)//If the square has a bomb
						{
							bombcount = bombcount+1;//Adds one to bombcount
						}
					}
				}
			}
			return bombcount;//Returns bombcount for use in other methods
	}

	public void recursivebombs()//The recursive method that goes through blank squares until a square is touching a bomb
	{
		for(int x = -1; x<=1;x++)//Same as above
			{
				for(int y = -1; y<=1;y++)//Same as above
				{
					GameSquare gs = board.getSquareAt(this.xLocation + x, this.yLocation + y);//Same as above
					BombSquare xs = (BombSquare)gs;//Same as above
					if(xs != null)//Same as above
					{
						if(!xs.thisSquareHasBomb & xs.bombchecker() == 0 & !xs.clicked)//Checks if the current BombSquare does not have a bomb, has not been clicked and that there are no bombs around it
							{
								xs.setImage("0.png");//Sets the current BombSquare image to 0 
								xs.clicked = true;//Sets clicked to true so it cannot be infinitely clicked
								xs.recursivebombs();//Calls recurisve bombs on the current BombSquare to repeat the process
							}
							else if(!xs.thisSquareHasBomb & !xs.clicked & xs.bombchecker() != 0)//Checks the same as above except if there are bombs around the current square
							{ 
								xs.setImage(xs.bombchecker()+".png");//Sets the current BombSquare image to the current BombSquare count
								xs.clicked = true;//Same as above
							}
					}
				}
			}
	}

	public void clicked()//The method called on a BombSquare when it is clicked
	{
		this.clicked = true;//Sets clicked to true

		if(thisSquareHasBomb == true)//If the current square has a bomb
		{
			this.setImage("bomb.png");//Sets current square image to the bomb.png
		}
		else if(bombchecker()==0)//Checks if the bombcount of the current square is 0
		{
			this.setImage("0.png");//Sets the current square to 0
			this.recursivebombs();//Calls recursive bombs on the current BombSquare
		}
		else if(bombchecker() != 0)//Checks if the bombcount isn't 0
		{
			this.setImage(bombchecker()+".png");//Sets the current BombSquare image to the bombount.png
		}
	}
}
